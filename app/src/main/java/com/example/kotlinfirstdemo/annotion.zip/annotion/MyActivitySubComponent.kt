package com.example.kotlinfirstdemo.annotion

import com.example.kotlinfirstdemo.ui.activity.MainActivity
import dagger.Subcomponent


//@MyActivityScope
@Subcomponent(modules = [MyActivityModule::class])
interface MyActivitySubComponent {
//    fun inject(activity: MainActivity?)
}