package com.example.kotlinfirstdemo.annotion

import javax.inject.Scope

//@Scope
public interface UserScope {

}