package com.example.kotlinfirstdemo.annotion
interface MyActivityScope  {
    
}