package com.example.kotlinfirstdemo.annotion

import android.app.Application
import dagger.Module

@Module
class AppModule {
//    var mApplication : Application ?= null
//    constructor(application: Application){
//        mApplication = application
//    }
//
//    fun providesApplication(): Application? {
//        return mApplication
//    }
}