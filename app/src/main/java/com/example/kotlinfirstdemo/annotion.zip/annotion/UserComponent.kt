package com.example.kotlinfirstdemo.annotion

import com.example.kotlinfirstdemo.ui.activity.MainActivity

//@UserScope
interface UserComponent {
//    fun inject(activity:MainActivity)
}