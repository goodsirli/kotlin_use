package com.example.kotlinfirstdemo.annotion

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager
import com.google.gson.FieldNamingPolicy
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import dagger.Module
import dagger.Provides
import okhttp3.Cache
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
class NetModule {

//    var mContext : Context ?= null
//    var mBaseUrl :String ?= null
//
//    constructor(baseUrl:String){
//        this.mBaseUrl = baseUrl
//    }
//
//    constructor(baseUrl:String,context:Context){
//        this.mBaseUrl = baseUrl
//        this.mContext = context
//    }
//
//    @Singleton
//    @Provides
//    fun getSharePreference(application:Application):SharedPreferences{
//        return PreferenceManager.getDefaultSharedPreferences(application)
//
//    }
//
//
//    @Provides
//    @Singleton
//    fun provideOkHttpCache(application:Application):Cache{
//        val size = 10 * 1024 * 1024L
//        val cache = Cache(application.cacheDir,size);
//        return cache
//    }
//
//    @Provides
//    @Singleton
//    fun provideGson():Gson{
//        val gsonBuilder = GsonBuilder()
//        gsonBuilder.setFieldNamingPolicy(FieldNamingPolicy.LOWER_CASE_WITH_UNDERSCORES)
//        return gsonBuilder.create()
//    }
//
//    @Provides
//    @Singleton
//    fun provideOkHttpClient(cache:Cache):OkHttpClient{
//        val builder = OkHttpClient.Builder()
//        return builder.cache(cache).build()
//    }
//
//    @Provides
//    @Singleton
//    fun provideRetrofit(gson:Gson,okHttpClient: OkHttpClient):Retrofit{
//
//        val retrofit = Retrofit
//            .Builder()
//            .addConverterFactory(GsonConverterFactory.create(gson))
//            .baseUrl(mBaseUrl)
//            .client(okHttpClient)
//            .build()
//
//        return retrofit
//    }

}