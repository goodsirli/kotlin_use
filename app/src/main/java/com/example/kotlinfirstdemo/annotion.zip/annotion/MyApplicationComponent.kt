package com.example.kotlinfirstdemo.annotion

import dagger.Module
import javax.inject.Singleton

@Singleton
@Module
interface MyApplicationComponent {
//    fun newMyActivitySubComponent(activityModule: MyActivityModule): MyApplicationComponent

}