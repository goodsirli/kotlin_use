package com.example.kotlinfirstdemo.annotion

import android.content.SharedPreferences
import com.example.kotlinfirstdemo.ui.activity.MainActivity
import dagger.Component
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import javax.inject.Singleton


@Singleton
@Component(modules = [NetModule::class,AppModule::class])
interface AppComponent {
//    fun inject(activity: MainActivity?)
//
//    fun retrofit():Retrofit
//    fun okHttpClient():OkHttpClient
//    fun sharedPreferences():SharedPreferences


}