package com.example.kotlinfirstdemo.annotion

import android.widget.ArrayAdapter
import com.example.kotlinfirstdemo.R
import com.example.kotlinfirstdemo.ui.activity.MainActivity
import dagger.Module
import dagger.Provides
import javax.inject.Named

@Module
class MyActivityModule {
//    private var mActivity: MainActivity ?= null
//
//    constructor(activity: MainActivity){
//        this.mActivity = activity
//    }
//
//
////    @Provides @MyActivityScope
//    @Named("my_list")
//    fun providesMyListAdapter() : ArrayAdapter<String>  {
//        return ArrayAdapter(mActivity!!.applicationContext,R.layout.firstfragment_tabitem)
//    }
}