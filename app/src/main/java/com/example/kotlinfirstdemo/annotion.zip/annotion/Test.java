package com.example.kotlinfirstdemo.annotion;

public class Test {

    public void test(){
    }
}
